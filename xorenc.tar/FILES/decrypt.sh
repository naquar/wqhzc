#! /bin/bash
read -s -p "Password: " password

find ./ -type f \
! -name decrypt.sh -exec \
openssl enc -a -d -k "$password" -pbkdf2 -iter 77777 -aes-256-cfb -in {} -out {}.dec \;

for file in *.dec; do
	mv "$file" "${file%.dec}";
done
